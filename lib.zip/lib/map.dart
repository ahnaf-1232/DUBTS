import 'package:dubts/controllers/busTrackerController.dart';
import 'package:dubts/services/firebaseService.dart';
import 'package:dubts/services/locationService.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class MapTrackerWidget extends StatefulWidget {
  final String busName;
  final String busCode;
  final String deviceId;
  final String busTime;

  const MapTrackerWidget({
    required this.busName,
    required this.busCode,
    required this.deviceId, 
    required this.busTime,
  });

  @override
  _MapTrackerWidgetState createState() => _MapTrackerWidgetState();
}

class _MapTrackerWidgetState extends State<MapTrackerWidget> {
  late final BusTrackerController _controller;
  LatLng? _currentPosition;

  @override
  void initState() {
    super.initState();
    _controller = BusTrackerController(
      busName: widget.busName,
      busCode: widget.busCode,
      deviceId: widget.deviceId,
      locationService: LocationService(),
      firebaseService: FirebaseService(),
    );
    _controller.startTracking();
  }

  @override
  void dispose() {
    _controller.stopTracking();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _currentPosition != null
          ? FlutterMap(
  options: MapOptions(
    center: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
    zoom: 16,
    maxZoom: 18,
    minZoom: 2.6,
  ),
  children: [
    TileLayer(
      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      userAgentPackageName: 'com.example.app',
    ),
    MarkerLayer(
      markers: [
        Marker(
          width: 40.0,
          height: 55.0,
          point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          builder: (ctx) => Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.fitWidth,
                    child: Container(
                      margin: EdgeInsets.all(10.0),
                      padding: EdgeInsets.all(10.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10.0),
                        color: Colors.red.shade900,
                      ),
                      child: Column(
                        children: [
                          Text(
                            '${widget.busName}',
                            textScaleFactor: 3,
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            '(${widget.busCode})',
                            textScaleFactor: 3,
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Icon(
                  Icons.location_pin,
                  color: Colors.red,
                  size: 25.0,
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  ],
)

          : Center(child: CircularProgressIndicator()),
    );
  }
}
