import 'package:dubts/models/busLocation.dart';
import 'package:firebase_database/firebase_database.dart';

class FirebaseService {
  final DatabaseReference _database = FirebaseDatabase.instance.ref();

  Future<void> updateBusLocation(
      String busName, String busCode, String deviceId, BusLocation location) async {
    String id = deviceId.replaceAll('.', '');
    DatabaseReference locationRef =
        _database.child('location/$busName/$busCode/$id');

    await locationRef.set(location.toJson());
    locationRef.onDisconnect().remove();
  }
}
