// Define the Bus interface
abstract class Bus {
  String? name;
  String? shortForm;
  List<String>? upTripBuses;
  List<String>? downTripBuses;
  String? route;
}