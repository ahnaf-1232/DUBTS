class CustomUser{
  final String uid;

  CustomUser(this.uid);
}