import 'dart:async';
import 'package:dubts/models/busLocation.dart';
import 'package:dubts/services/firebaseService.dart';
import 'package:dubts/services/locationService.dart';

class BusTrackerController {
  final String busName;
  final String busCode;
  final String deviceId;
  final LocationService _locationService;
  final FirebaseService _firebaseService;
  Timer? _timer;

  BusTrackerController({
    required this.busName,
    required this.busCode,
    required this.deviceId,
    required LocationService locationService,
    required FirebaseService firebaseService,
  })  : _locationService = locationService,
        _firebaseService = firebaseService;

  void startTracking({Duration interval = const Duration(seconds: 5)}) {
    _timer = Timer.periodic(interval, (timer) async {
      BusLocation? location = await _locationService.getCurrentLocation();
      if (location != null) {
        await _firebaseService.updateBusLocation(
            busName, busCode, deviceId, location);
      }
    });
  }

  void stopTracking() {
    _timer?.cancel();
  }
}
